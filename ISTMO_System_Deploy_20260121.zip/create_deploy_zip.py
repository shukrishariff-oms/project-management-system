import zipfile
import os
import datetime

def create_zip():
    timestamp = datetime.datetime.now().strftime("%Y%m%d")
    zip_filename = f"ISTMO_System_Deploy_{timestamp}.zip"
    
    # Files/Folders to include
    include_roots = ['.'] # Root
    
    # Exclusions
    exclude_dirs = {
        'node_modules', 'dist', 'build', '.git', '.vspace', '.vscode', '.idea',
        '__pycache__', 'venv', '.venv', 'env', '.gemini', 'tmp', 'coverage'
    }
    exclude_files = {
        '.DS_Store', 'Thumbs.db', 'pms_deploy.zip', zip_filename, 
        'sql_app_v2.db', 'debug.db' # Don't ship local DBs by default
    }
    exclude_extensions = {'.pyc', '.pyo', '.log', '.zip'}

    print(f"Creating {zip_filename}...")
    
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for root, dirs, files in os.walk('.'):
            # Modify dirs in-place to prune excluded directories
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                if file in exclude_files:
                    continue
                if any(file.endswith(ext) for ext in exclude_extensions):
                    continue
                
                file_path = os.path.join(root, file)
                # Archive name (relative path)
                arcname = os.path.relpath(file_path, '.')
                
                # Check if it's inside one of the excluded logic that might have slipped (safe check)
                parts = arcname.split(os.sep)
                if any(p in exclude_dirs for p in parts):
                    continue
                    
                print(f"Adding {arcname}")
                zipf.write(file_path, arcname)
                
    print(f"✅ Success! Zip created at: {os.path.abspath(zip_filename)}")

if __name__ == "__main__":
    create_zip()
